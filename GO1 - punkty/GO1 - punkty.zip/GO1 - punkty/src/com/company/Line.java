package com.company;

import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.util.concurrent.ThreadLocalRandom;

import static java.lang.Math.cos;
import static java.lang.Math.sin;

public class Line extends Point{
    private Point head = new Point();
    private Point tail = new Point();

    public Line(Point head, Point tail) {
        this.head = head;
        this.tail = tail;
    }

    public String functionY(){
        int a;
        int b;
        a = (head.y-tail.y)/(head.x-tail.x);
        b = head.y - a*head.x;
        String k =  "y= " + a + "*x + " + b;
        return k;
    }

    public String toString(){
        return "head: (" + head + "), tail: (" + tail + ")";
    }

    public String membership() {
        int a;
        int b;
        a = (head.y-tail.y)/(head.x-tail.x);
        b = head.y - a*head.x;
        x = ThreadLocalRandom.current().nextInt(0,100);
        y = ThreadLocalRandom.current().nextInt(0,100);

        Point rand = new Point(x, y);

        System.out.println("losowy punkt: " + rand);

        if(y==a*x + b && head.x<=x && x<=tail.x && head.y<=y && y<=tail.y){
            System.out.println("Punkt należy do prostej i odcinka");
        } else if (y==a*x + b){
            System.out.println("Punkt należy do prostej");
        }else {
            System.out.println("Punkt nie należy do prostej");
        }
        return " ";
    }

    Point vec = new Point(x,y);

    public String vector(Point vec){
        head.x += vec.x;
        head.y += vec.y;
        tail.x += vec.x;
        tail.y += vec.y;
        return "Po translakcji: ";
    }

    public String rotation(double degree){
        System.out.println("Po rotacji: ");
        Line a = new Line(new Point(head.x, head.y), new Point((int) (head.x*cos(degree*3.14/180)- head.y*sin(degree*3.14/180)), (int) (head.y*cos(degree*3.14/180)+head.x*sin(degree*3.14/180))));
        return a.toString();
    }

    public String ReflectionOX(){
        System.out.println("Odbicie względem osi OX:");
        Line a=new Line(new Point(head.x,-head.y),new Point(tail.x,-tail.y));
        return a.toString();
    }

    public String ReflectionOY(){
        System.out.println("Odbicie względem osi OY:");
        Line a=new Line(new Point(-head.x,head.y),new Point(-tail.x,tail.y));
        return a.toString();
    }
}
