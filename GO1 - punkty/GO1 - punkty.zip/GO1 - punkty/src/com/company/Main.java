package com.company;

import java.util.Scanner;
import java.util.Vector;
import java.util.function.Function;
import java.util.Random;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Podaj współrzędne punktów p1 i p2:");
        Point p1 = new Point(1,2);
        Point p2 = new Point(3,4);
        Point p3 = new Point();
        Point p4 = new Point();
        Point p5 = new Point();
        Line line = new Line(p1, p2);

        System.out.println("Punkty: ");
        System.out.println(p1);
        System.out.println(p2);
        System.out.println("Funkcja: " + line.functionY());

        System.out.println(line.membership());

        System.out.println("Podaj współrzędne wektora x i y: ");
        int v1 = scanner.nextInt();
        int v2 = scanner.nextInt();
        Point vector = new Point(v1, v2);
        System.out.println(line.vector(vector));
        System.out.println(line);

        System.out.println("Podaj stopnie do rotacji punktu: ");
        double degree = scanner.nextInt();
        System.out.println(line.rotation(degree));

        System.out.println(line.ReflectionOX());
        System.out.println(line.ReflectionOY());
    }
}
