package com.company;

import java.awt.*;

public class Main {

    public static void main(String[] args) {
        Program p = new Program();
        Point p1 = new Point(10,10);
        Point p2 = new Point(1,1);
    }
}
