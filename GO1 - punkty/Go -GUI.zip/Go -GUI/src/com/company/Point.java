package com.company;

import java.util.List;

public class Point extends Program{
    float x;
    float y;

    public Point(float x, float y) {
        this.x = x;
        this.y = y;
    }
    public Point(){
    }

    public String toString(){
        return "x= " + x + ", y= " + y;
    }

    public Point randoPoint(){
        x= 100 + ((float)Math.random()*800);
        y= 100 + ((float)Math.random()*800);
        Point zad1 = new Point(x,y);
        return zad1;
    }

    public void calcFunc(Point p1, Point p2, List w)
    {
        float a;
        float b;
        a = (p1.y-p2.y)/(p1.x-p2.x);
        b = p1.y - a*p1.x;
        w.add(a);
        w.add(b);
    }

    public void whichSide(float x1, float y1, float x2, float y2, Point p3){
        float a,b,A,B,C;
        a = (y1-y2)/(x1-x2);
        b = y1 - a*x1;
        A = -a;
        B = 1;
        C = -b;

        if((A*p3.x+B*p3.y+C)<0){
            System.out.println("Punkt jest z lewej strony!");
        } else if(A*p3.x+B*p3.y+C>0) {
            System.out.println("Punkt jest z prawej strony!");
        } else {
            System.out.println("Punkt jest na prostej!");
        }
    }
}
