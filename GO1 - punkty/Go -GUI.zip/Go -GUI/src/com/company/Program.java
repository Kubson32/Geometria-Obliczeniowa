package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Line2D;
import java.util.Random;

public class Program extends JFrame {

    Random l = new Random();

    public Program(){
        setTitle("Układ współrzędnych");
        setSize(1000,1000);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

    }

    public void paint(Graphics g){


        g.drawLine(0,500,1000,500);
        g.drawLine(500,0,500,1000);
        int a = l.nextInt(-10,10);
        int b = l.nextInt(-10,10);

        g.drawLine(0,100*5,1000,100*a);
    }

    public void point(Graphics g){
        super.printComponents(g);
        g.fillOval(100,100,100,100);
    }
}
